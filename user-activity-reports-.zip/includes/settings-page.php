<?php
// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
    die;
}

/**
 * Add the settings page to the User Activity Reports menu.
 */
function uar_add_settings_page() {
    add_submenu_page(
        'user-activity-reports',
        __( 'Settings', 'user-activity-reports' ),
        __( 'Settings', 'user-activity-reports' ),
        'manage_options',
        'user-activity-reports-settings',
        'uar_settings_page'
    );
}
add_action( 'admin_menu', 'uar_add_settings_page' );

/**
 * Display the settings page.
 */
function uar_settings_page() {
    ?>
    <div class="wrap">
        <h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
        <form action="options.php" method="post">
            <?php
            settings_fields( 'uar_settings' );
            do_settings_sections( 'uar_settings' );
            submit_button();
            ?>
        </form>
    </div>
    <?php
}

/**
 * Register the settings.
 */
function uar_register_settings() {
    register_setting( 'uar_settings', 'uar_settings_enable_tracking', 'sanitize_text_field' );
    register_setting( 'uar_settings', 'uar_settings_excluded_roles', 'uar_sanitize_excluded_roles' );
    register_setting( 'uar_settings', 'uar_settings_excluded_post_ids', 'sanitize_text_field' );
    register_setting( 'uar_settings', 'uar_settings_data_retention', 'sanitize_text_field' );

    add_settings_section(
        'uar_settings_section_tracking',
        __( 'Tracking Settings', 'user-activity-reports' ),
        'uar_settings_section_tracking_callback',
        'uar_settings'
    );

    add_settings_field(
        'uar_settings_enable_tracking',
        __( 'Enable User Activity Tracking', 'user-activity-reports' ),
        'uar_settings_enable_tracking_callback',
        'uar_settings',
        'uar_settings_section_tracking'
    );

    add_settings_field(
        'uar_settings_excluded_roles',
        __( 'Exclude User Roles', 'user-activity-reports' ),
        'uar_settings_excluded_roles_callback',
        'uar_settings',
        'uar_settings_section_tracking'
    );

    add_settings_field(
        'uar_settings_excluded_post_ids',
        __( 'Exclude Post IDs', 'user-activity-reports' ),
        'uar_settings_excluded_post_ids_callback',
        'uar_settings',
        'uar_settings_section_tracking'
    );

    add_settings_field(
        'uar_settings_data_retention',
        __( 'Data Retention Period', 'user-activity-reports' ),
        'uar_settings_data_retention_callback',
        'uar_settings',
        'uar_settings_section_tracking'
    );
}
add_action( 'admin_init', 'uar_register_settings' );

/**
 * Callback for the tracking settings section.
 */
function uar_settings_section_tracking_callback() {
    echo '<p>' . __( 'Configure the user activity tracking settings.', 'user-activity-reports' ) . '</p>';
}

/**
 * Callback for the enable tracking setting.
 */
function uar_settings_enable_tracking_callback() {
    $option = get_option( 'uar_settings_enable_tracking', 'enabled' );
    ?>
    <select name="uar_settings_enable_tracking">
        <option value="enabled" <?php selected( $option, 'enabled' ); ?>><?php _e( 'Enabled', 'user-activity-reports' ); ?></option>
        <option value="disabled" <?php selected( $option, 'disabled' ); ?>><?php _e( 'Disabled', 'user-activity-reports' ); ?></option>
    </select>
    <?php
}

/**
 * Callback for the excluded roles setting.
 */
function uar_settings_excluded_roles_callback() {
    global $wp_roles;
    $roles = $wp_roles->get_names();
    $excluded_roles = (array) get_option( 'uar_settings_excluded_roles', array() );

    foreach ( $roles as $role_value => $role_name ) {
        ?>
        <label>
            <input type="checkbox" name="uar_settings_excluded_roles[]" value="<?php echo esc_attr( $role_value ); ?>" <?php checked( in_array( $role_value, $excluded_roles ) ); ?>>
            <?php echo esc_html( $role_name ); ?>
        </label><br>
        <?php
    }
}

/**
 * Callback for the excluded post IDs setting.
 */
function uar_settings_excluded_post_ids_callback() {
    $excluded_post_ids = get_option( 'uar_settings_excluded_post_ids', '' );
    ?>
    <input type="text" name="uar_settings_excluded_post_ids" value="<?php echo esc_attr( $excluded_post_ids ); ?>" class="regular-text">
    <p class="description"><?php _e( 'Enter a comma-separated list of post IDs to exclude from tracking.', 'user-activity-reports' ); ?></p>
    <?php
}

/**
 * Callback for the data retention setting.
 */
function uar_settings_data_retention_callback() {
    $option = get_option( 'uar_settings_data_retention', 'never' );
    ?>
    <select name="uar_settings_data_retention">
        <option value="never" <?php selected( $option, 'never' ); ?>><?php _e( 'Never delete', 'user-activity-reports' ); ?></option>
        <option value="1 month" <?php selected( $option, '1 month' ); ?>><?php _e( '1 month', 'user-activity-reports' ); ?></option>
        <option value="3 months" <?php selected( $option, '3 months' ); ?>><?php _e( '3 months', 'user-activity-reports' ); ?></option>
        <option value="6 months" <?php selected( $option, '6 months' ); ?>><?php _e( '6 months', 'user-activity-reports' ); ?></option>
        <option value="1 year" <?php selected( $option, '1 year' ); ?>><?php _e( '1 year', 'user-activity-reports' ); ?></option>
        <option value="2 years" <?php selected( $option, '2 years' ); ?>><?php _e( '2 years', 'user-activity-reports' ); ?></option>
    </select>
    <?php
}

/**
 * Sanitize the excluded roles setting.
 */
function uar_sanitize_excluded_roles( $input ) {
    return is_array( $input ) ? array_map( 'sanitize_text_field', $input ) : array();
}

/**
 * Display a GDPR admin notice.
 */
function uar_gdpr_admin_notice() {
    $tracking_enabled = get_option( 'uar_settings_enable_tracking', 'enabled' );
    if ( $tracking_enabled === 'enabled' ) {
        ?>
        <div class="notice notice-info is-dismissible">
            <p><?php _e( 'The User Activity Reports plugin is currently tracking user activity. Please ensure your privacy policy reflects this.', 'user-activity-reports' ); ?></p>
        </div>
        <?php
    }
}
add_action( 'admin_notices', 'uar_gdpr_admin_notice' );
