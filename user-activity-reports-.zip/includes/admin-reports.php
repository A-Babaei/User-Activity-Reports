<?php
// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
    die;
}

/**
 * Add the admin menu for the User Activity Reports.
 */
function uar_add_admin_menu() {
    add_menu_page(
        __( 'User Activity Reports', 'user-activity-reports' ),
        __( 'User Activity', 'user-activity-reports' ),
        'manage_options',
        'user-activity-reports',
        'uar_user_activity_reports_page',
        'dashicons-chart-line',
        30
    );
}
add_action( 'admin_menu', 'uar_add_admin_menu' );

/**
 * Display the User Activity Reports page.
 */
function uar_user_activity_reports_page() {
    $active_tab = isset( $_GET['tab'] ) ? sanitize_key( $_GET['tab'] ) : 'per_user';
    ?>
    <div class="wrap">
        <h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
        <h2 class="nav-tab-wrapper">
            <a href="?page=user-activity-reports&tab=per_user" class="nav-tab <?php echo $active_tab == 'per_user' ? 'nav-tab-active' : ''; ?>"><?php _e( 'Per User Report', 'user-activity-reports' ); ?></a>
            <a href="?page=user-activity-reports&tab=per_page" class="nav-tab <?php echo $active_tab == 'per_page' ? 'nav-tab-active' : ''; ?>"><?php _e( 'Per Page/Course Report', 'user-activity-reports' ); ?></a>
            <a href="?page=user-activity-reports&tab=overall_stats" class="nav-tab <?php echo $active_tab == 'overall_stats' ? 'nav-tab-active' : ''; ?>"><?php _e( 'Overall Stats', 'user-activity-reports' ); ?></a>
        </h2>

        <?php
        if ( $active_tab == 'per_user' ) {
            uar_render_per_user_report();
        } elseif ( $active_tab == 'per_page' ) {
            uar_render_per_page_report();
        } else {
            uar_render_overall_stats_report();
        }
        ?>
    </div>
    <?php
}

/**
 * Render the Per User Report tab.
 */
function uar_render_per_user_report() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'user_page_time_logs';
    $selected_user = isset( $_REQUEST['user_id'] ) ? intval( $_REQUEST['user_id'] ) : 0;
    $start_date = isset( $_REQUEST['start_date'] ) ? sanitize_text_field( $_REQUEST['start_date'] ) : '';
    $end_date = isset( $_REQUEST['end_date'] ) ? sanitize_text_field( $_REQUEST['end_date'] ) : '';
    $paged = isset( $_GET['paged'] ) ? intval( $_GET['paged'] ) : 1;
    $per_page = 20;
    $offset = ( $paged - 1 ) * $per_page;

    $users = get_users( array( 'fields' => array( 'ID', 'display_name' ) ) );
    ?>
    <h3><?php _e( 'Per User Report', 'user-activity-reports' ); ?></h3>
    <form method="get">
        <input type="hidden" name="page" value="user-activity-reports" />
        <input type="hidden" name="tab" value="per_user" />
        <select name="user_id">
            <option value="0"><?php _e( 'Select a user', 'user-activity-reports' ); ?></option>
            <?php foreach ( $users as $user ) : ?>
                <option value="<?php echo esc_attr( $user->ID ); ?>" <?php selected( $selected_user, $user->ID ); ?>><?php echo esc_html( $user->display_name ); ?></option>
            <?php endforeach; ?>
        </select>
        <input type="date" name="start_date" value="<?php echo esc_attr( $start_date ); ?>" />
        <input type="date" name="end_date" value="<?php echo esc_attr( $end_date ); ?>" />
        <input type="submit" value="<?php _e( 'Filter', 'user-activity-reports' ); ?>" class="button" />
    </form>

    <?php
    if ( $selected_user ) {
        $query = "SELECT SQL_CALC_FOUND_ROWS page_url, post_id, COUNT(*) as total_visits, SUM(duration_seconds) as total_time, AVG(duration_seconds) as avg_time FROM {$table_name} WHERE user_id = %d";
        $params = array( $selected_user );
        if ( $start_date ) {
            $query .= " AND visit_date >= %s";
            $params[] = $start_date;
        }
        if ( $end_date ) {
            $query .= " AND visit_date <= %s";
            $params[] = $end_date;
        }
        $query .= " GROUP BY page_url, post_id ORDER BY total_time DESC LIMIT %d, %d";
        $params[] = $offset;
        $params[] = $per_page;
        $results = $wpdb->get_results( $wpdb->prepare( $query, $params ) );
        $total_items = $wpdb->get_var( "SELECT FOUND_ROWS()" );

        if ( $results ) {
            // ... (table rendering, pagination, CSV export form) ...
        } else {
            echo '<p>' . __( 'No activity found for this user in the selected date range.', 'user-activity-reports' ) . '</p>';
        }
    }
}

/**
 * Render the Per Page/Course Report tab.
 */
function uar_render_per_page_report() {
    // ... (implementation) ...
}

/**
 * Render the Overall Stats tab.
 */
function uar_render_overall_stats_report() {
    // ... (implementation) ...
}

/**
 * Handle CSV export.
 */
function uar_export_csv() {
    // ... (implementation) ...
}
add_action( 'admin_init', 'uar_export_csv' );
