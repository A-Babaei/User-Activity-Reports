<?php
// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
    die;
}

/**
 * Schedule the data pruning cron job.
 */
function uar_schedule_data_pruning_cron() {
    if ( ! wp_next_scheduled( 'uar_data_pruning_event' ) ) {
        wp_schedule_event( time(), 'daily', 'uar_data_pruning_event' );
    }
}
add_action( 'wp', 'uar_schedule_data_pruning_cron' );

/**
 * Perform the data pruning.
 */
function uar_perform_data_pruning() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'user_page_time_logs';
    $retention_period = get_option( 'uar_settings_data_retention', 'never' );

    if ( $retention_period !== 'never' ) {
        $date = date( 'Y-m-d H:i:s', strtotime( "-{$retention_period}" ) );
        $wpdb->query( $wpdb->prepare( "DELETE FROM {$table_name} WHERE start_time < %s", $date ) );
    }
}
add_action( 'uar_data_pruning_event', 'uar_perform_data_pruning' );

/**
 * Unschedule the data pruning cron job on plugin deactivation.
 */
function uar_deschedule_data_pruning_cron() {
    wp_clear_scheduled_hook( 'uar_data_pruning_event' );
}
