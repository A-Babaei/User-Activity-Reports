<?php
/*
Plugin Name: User Activity Reports
Plugin URI: https://academy-tech.ir/
Description: Tracks user activity to provide insights into student engagement.
Version: 1.0.0
Author: Jules
Author URI: https://academy-tech.ir/
License: GPL2
Text Domain: user-activity-reports
*/

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
    die;
}

/**
 * Create the custom database table on plugin activation.
 */
function uar_activate_plugin() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'user_page_time_logs';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        user_id bigint(20) NOT NULL,
        post_id bigint(20) NOT NULL,
        page_url text NOT NULL,
        start_time datetime NOT NULL,
        duration_seconds int(11) NOT NULL DEFAULT 0,
        visit_date date NOT NULL,
        session_hash varchar(32) DEFAULT '' NOT NULL,
        PRIMARY KEY (id),
        KEY user_id (user_id),
        KEY post_id (post_id),
        KEY visit_date (visit_date)
    ) $charset_collate;";

    require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
    dbDelta( $sql );
}
register_activation_hook( __FILE__, 'uar_activate_plugin' );
register_deactivation_hook( __FILE__, 'uar_deschedule_data_pruning_cron' );

/**
 * Enqueue scripts and localize data.
 */
function uar_enqueue_scripts() {
    if ( is_admin() || is_preview() || is_customize_preview() ) {
        return;
    }
    
    $tracking_enabled = get_option( 'uar_settings_enable_tracking', 'enabled' );
    if ( $tracking_enabled === 'disabled' || ! is_user_logged_in() ) {
        return;
    }

    $excluded_roles = (array) get_option( 'uar_settings_excluded_roles', array() );
    $user = wp_get_current_user();
    if ( array_intersect( $excluded_roles, $user->roles ) ) {
        return;
    }

    $excluded_post_ids = array_map( 'trim', explode( ',', get_option( 'uar_settings_excluded_post_ids', '' ) ) );
    if ( in_array( get_the_ID(), $excluded_post_ids ) ) {
        return;
    }

    wp_enqueue_script(
        'uar-activity-tracking',
        plugin_dir_url( __FILE__ ) . 'assets/js/activity-tracking.js',
        array(),
        '1.0.0',
        true
    );

    wp_localize_script(
        'uar-activity-tracking',
        'uar_activity_tracking',
        array(
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'nonce' => wp_create_nonce( 'uar_activity_tracking_nonce' ),
            'post_id' => get_the_ID(),
            'is_user_logged_in' => is_user_logged_in(),
        )
    );
}
add_action( 'wp_enqueue_scripts', 'uar_enqueue_scripts' );

/**
 * Include plugin files.
 */
require_once( plugin_dir_path( __FILE__ ) . 'includes/ajax-handlers.php' );
require_once( plugin_dir_path( __FILE__ ) . 'includes/cron.php' );
if ( is_admin() ) {
    require_once( plugin_dir_path( __FILE__ ) . 'includes/admin-reports.php' );
    require_once( plugin_dir_path( __FILE__ ) . 'includes/settings-page.php' );
}
