<?php
// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
    die;
}

/**
 * AJAX handler for starting to track user activity.
 */
function uar_activity_start_tracking() {
    check_ajax_referer( 'uar_activity_tracking_nonce', 'nonce' );

    global $wpdb;
    $table_name = $wpdb->prefix . 'user_page_time_logs';
    $user_id = get_current_user_id();

    if ( ! $user_id ) {
        wp_send_json_error( array( 'message' => 'User not logged in.' ) );
    }

    $post_id = isset( $_POST['post_id'] ) ? intval( $_POST['post_id'] ) : 0;
    $page_url = isset( $_POST['page_url'] ) ? esc_url_raw( $_POST['page_url'] ) : '';
    $start_time = isset( $_POST['start_time'] ) ? sanitize_text_field( $_POST['start_time'] ) : current_time( 'mysql' );
    
    $session_hash = md5( $user_id . $start_time . $page_url );

    $result = $wpdb->insert(
        $table_name,
        array(
            'user_id' => $user_id,
            'post_id' => $post_id,
            'page_url' => $page_url,
            'start_time' => $start_time,
            'visit_date' => current_time( 'Y-m-d' ),
            'session_hash' => $session_hash,
        )
    );

    if ( $result === false ) {
        wp_send_json_error( array( 'message' => 'Failed to insert tracking data.' ) );
    }

    $log_id = $wpdb->insert_id;

    wp_send_json_success( array( 'log_id' => $log_id ) );
}
add_action( 'wp_ajax_uar_activity_start', 'uar_activity_start_tracking' );

/**
 * AJAX handler for updating the duration of the user activity.
 */
function uar_activity_update_tracking() {
    check_ajax_referer( 'uar_activity_tracking_nonce', 'nonce' );

    global $wpdb;
    $table_name = $wpdb->prefix . 'user_page_time_logs';
    $user_id = get_current_user_id();

    if ( ! $user_id ) {
        wp_send_json_error( array( 'message' => 'User not logged in.' ) );
    }

    $log_id = isset( $_POST['log_id'] ) ? intval( $_POST['log_id'] ) : 0;
    $duration_seconds = isset( $_POST['duration_seconds'] ) ? intval( $_POST['duration_seconds'] ) : 0;

    if ( ! $log_id ) {
        wp_send_json_error( array( 'message' => 'Log ID not provided.' ) );
    }

    // Verify the log entry belongs to the current user to prevent manipulation.
    $log_user_id = $wpdb->get_var( $wpdb->prepare( "SELECT user_id FROM $table_name WHERE id = %d", $log_id ) );

    if ( $log_user_id != $user_id ) {
        wp_send_json_error( array( 'message' => 'Invalid log entry.' ) );
    }

    $result = $wpdb->update(
        $table_name,
        array(
            'duration_seconds' => $duration_seconds,
        ),
        array(
            'id' => $log_id,
        )
    );

    if ( $result === false ) {
        wp_send_json_error( array( 'message' => 'Failed to update tracking data.' ) );
    }

    wp_send_json_success();
}
add_action( 'wp_ajax_uar_activity_update', 'uar_activity_update_tracking' );
