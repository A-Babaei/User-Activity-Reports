<?php
/**
 * Admin Reports Page
 *
 * @package User_Activity_Reports
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
    die;
}

/**
 * Add the admin menu item for the reports page.
 */
function uar_add_admin_menu() {
    add_menu_page(
        __( 'User Activity Reports', 'user-activity-reports' ),
        __( 'Activity Reports', 'user-activity-reports' ),
        'manage_options',
        'uar-user-activity-reports',
        'uar_user_activity_reports_page',
        'dashicons-chart-bar',
        30
    );
}
add_action( 'admin_menu', 'uar_add_admin_menu' );

/**
 * Render the main user activity reports page.
 */
function uar_user_activity_reports_page() {
    ?>
    <div class="wrap">
        <h1><?php esc_html_e( 'User Activity Reports', 'user-activity-reports' ); ?></h1>
        <?php
        uar_first_time_admin_notice();
        $active_tab = isset( $_GET['tab'] ) ? sanitize_key( $_GET['tab'] ) : 'per_user';
        ?>
        <nav class="nav-tab-wrapper">
            <a href="?page=uar-user-activity-reports&tab=per_user" class="nav-tab <?php echo $active_tab === 'per_user' ? 'nav-tab-active' : ''; ?>"><?php esc_html_e( 'Per User', 'user-activity-reports' ); ?></a>
            <a href="?page=uar-user-activity-reports&tab=per_page" class="nav-tab <?php echo $active_tab === 'per_page' ? 'nav-tab-active' : ''; ?>"><?php esc_html_e( 'Per Page/Course', 'user-activity-reports' ); ?></a>
            <a href="?page=uar-user-activity-reports&tab=overall_stats" class="nav-tab <?php echo $active_tab === 'overall_stats' ? 'nav-tab-active' : ''; ?>"><?php esc_html_e( 'Overall Stats', 'user-activity-reports' ); ?></a>
            <a href="?page=uar-user-activity-reports&tab=settings" class="nav-tab <?php echo $active_tab === 'settings' ? 'nav-tab-active' : ''; ?>"><?php esc_html_e( 'Settings', 'user-activity-reports' ); ?></a>
        </nav>
        <div class="tab-content">
            <?php
            switch ( $active_tab ) {
                case 'per_user':
                    uar_render_per_user_report();
                    break;
                case 'per_page':
                    uar_render_per_page_report();
                    break;
                case 'overall_stats':
                    uar_render_overall_stats_report();
                    break;
                case 'settings':
                    settings_errors();
                    ?>
                    <form method="post" action="options.php">
                        <?php
                        settings_fields( 'uar_settings' );
                        do_settings_sections( 'uar_settings' );
                        submit_button();
                        ?>
                    </form>
                    <?php
                    break;
            }
            ?>
        </div>
    </div>
    <?php
}

/**
 * Format seconds into a human-readable format.
 */
function uar_format_time( $seconds ) {
    $hours = floor( $seconds / 3600 );
    $minutes = floor( ( $seconds / 60 ) % 60 );
    $seconds = $seconds % 60;
    return sprintf( '%dh %dm %ds', $hours, $minutes, $seconds );
}

/**
 * Display a notice on the reports page for first-time users.
 */
function uar_first_time_admin_notice() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'user_page_time_logs';
    $row_count = $wpdb->get_var( "SELECT COUNT(*) FROM $table_name" );

    if ( $row_count == 0 && ! isset( $_COOKIE['uar_admin_notice_dismissed'] ) ) {
        ?>
        <div class="notice notice-info is-dismissible uar-admin-notice">
            <p><?php _e( 'User activity tracking is active. Data will appear here after logged-in users visit your content pages. Tip: Tracking only records time for logged-in members.', 'user-activity-reports' ); ?></p>
        </div>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                document.querySelector('.uar-admin-notice .notice-dismiss').addEventListener('click', function() {
                    document.cookie = 'uar_admin_notice_dismissed=true; path=/';
                });
            });
        </script>
        <?php
    }
}

/**
 * Render the Per User report.
 */
function uar_render_per_user_report() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'user_page_time_logs';
    $selected_user = isset( $_GET['user_id'] ) ? intval( $_GET['user_id'] ) : 0;
    $start_date = isset( $_GET['start_date'] ) ? sanitize_text_field( $_GET['start_date'] ) : '';
    $end_date = isset( $_GET['end_date'] ) ? sanitize_text_field( $_GET['end_date'] ) : '';

    ?>
    <h2><?php esc_html_e( 'Per User Report', 'user-activity-reports' ); ?></h2>
    <form method="get">
        <input type="hidden" name="page" value="uar-user-activity-reports">
        <input type="hidden" name="tab" value="per_user">
        <?php
        wp_dropdown_users( array(
            'name' => 'user_id',
            'selected' => $selected_user,
            'show_option_all' => __( 'Select a user', 'user-activity-reports' ),
        ) );
        ?>
        <label for="start_date"><?php esc_html_e( 'Start Date:', 'user-activity-reports' ); ?></label>
        <input type="date" id="start_date" name="start_date" value="<?php echo esc_attr( $start_date ); ?>">
        <label for="end_date"><?php esc_html_e( 'End Date:', 'user-activity-reports' ); ?></label>
        <input type="date" id="end_date" name="end_date" value="<?php echo esc_attr( $end_date ); ?>">
        <input type="submit" class="button" value="<?php esc_attr_e( 'Show Report', 'user-activity-reports' ); ?>">
    </form>
    <?php

    if ( ! $selected_user ) {
        echo '<p>' . esc_html__( 'Please select a user to view their activity report.', 'user-activity-reports' ) . '</p>';
        return;
    }

    $items_per_page = 20;
    $current_page = isset( $_GET['paged'] ) ? absint( $_GET['paged'] ) : 1;
    $offset = ( $current_page - 1 ) * $items_per_page;

    $sql = "SELECT SQL_CALC_FOUND_ROWS page_url, post_id, COUNT(*) as total_visits, SUM(duration_seconds) as total_time, AVG(duration_seconds) as avg_time FROM {$table_name} WHERE user_id = %d";
    
    $params = array( $selected_user );

    if ( ! empty( $start_date ) ) {
        $sql .= " AND visit_date >= %s";
        $params[] = $start_date;
    }

    if ( ! empty( $end_date ) ) {
        $sql .= " AND visit_date <= %s";
        $params[] = $end_date;
    }

    $sql .= " GROUP BY page_url, post_id LIMIT %d, %d";
    $params[] = $offset;
    $params[] = $items_per_page;

    $query = $wpdb->prepare( $sql, $params );
    $results = $wpdb->get_results( $query );

    $total_items = $wpdb->get_var( "SELECT FOUND_ROWS()" );

    if ( $results ) {
        ?>
        <a href="<?php echo esc_url( add_query_arg( array( 'action' => 'uar_export_csv', 'report' => 'per_user', 'user_id' => $selected_user, 'start_date' => $start_date, 'end_date' => $end_date ), admin_url( 'admin.php' ) ) ); ?>" class="button button-primary"><?php esc_html_e( 'Export to CSV', 'user-activity-reports' ); ?></a>
        <table class="widefat fixed" cellspacing="0">
            <thead>
                <tr>
                    <th><?php esc_html_e( 'Page/Post Title', 'user-activity-reports' ); ?></th>
                    <th><?php esc_html_e( 'URL', 'user-activity-reports' ); ?></th>
                    <th><?php esc_html_e( 'Total Visits', 'user-activity-reports' ); ?></th>
                    <th><?php esc_html_e( 'Total Time Spent', 'user-activity-reports' ); ?></th>
                    <th><?php esc_html_e( 'Average Time per Visit', 'user-activity-reports' ); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ( $results as $row ) : ?>
                    <tr>
                        <td><?php echo esc_html( get_the_title( $row->post_id ) ); ?></td>
                        <td><a href="<?php echo esc_url( $row->page_url ); ?>" target="_blank"><?php echo esc_url( $row->page_url ); ?></a></td>
                        <td><?php echo esc_html( $row->total_visits ); ?></td>
                        <td><?php echo esc_html( uar_format_time( $row->total_time ) ); ?></td>
                        <td><?php echo esc_html( uar_format_time( round( $row->avg_time ) ) ); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php
        $total_pages = ceil( $total_items / $items_per_page );
        if ( $total_pages > 1 ) {
            $pagination_args = array(
                'base' => add_query_arg( 'paged', '%#%' ),
                'format' => '',
                'current' => $current_page,
                'total' => $total_pages,
            );
            echo '<div class="tablenav"><div class="tablenav-pages">' . paginate_links( $pagination_args ) . '</div></div>';
        }
    } else {
        echo '<p>' . esc_html__( 'No activity found for this user.', 'user-activity-reports' ) . '</p>';
    }
}

/**
 * Render the Per Page/Course report.
 */
function uar_render_per_page_report() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'user_page_time_logs';
    $start_date = isset( $_GET['start_date'] ) ? sanitize_text_field( $_GET['start_date'] ) : '';
    $end_date = isset( $_GET['end_date'] ) ? sanitize_text_field( $_GET['end_date'] ) : '';
    $selected_role = isset( $_GET['role'] ) ? sanitize_text_field( $_GET['role'] ) : '';
    $group_by_course = isset( $_GET['group_by_course'] ) ? 1 : 0;

    ?>
    <h2><?php esc_html_e( 'Per Page/Course Report', 'user-activity-reports' ); ?></h2>
    <form method="get">
        <input type="hidden" name="page" value="uar-user-activity-reports">
        <input type="hidden" name="tab" value="per_page">
        <label for="start_date"><?php esc_html_e( 'Start Date:', 'user-activity-reports' ); ?></label>
        <input type="date" id="start_date" name="start_date" value="<?php echo esc_attr( $start_date ); ?>">
        <label for="end_date"><?php esc_html_e( 'End Date:', 'user-activity-reports' ); ?></label>
        <input type="date" id="end_date" name="end_date" value="<?php echo esc_attr( $end_date ); ?>">
        <label for="role"><?php esc_html_e( 'User Role:', 'user-activity-reports' ); ?></label>
        <select name="role" id="role">
            <option value=""><?php _e( 'All Roles', 'user-activity-reports' ); ?></option>
            <?php
            global $wp_roles;
            foreach ( $wp_roles->get_names() as $role => $name ) {
                echo '<option value="' . esc_attr( $role ) . '" ' . selected( $selected_role, $role, false ) . '>' . esc_html( $name ) . '</option>';
            }
            ?>
        </select>
        <label>
            <input type="checkbox" name="group_by_course" value="1" <?php checked( $group_by_course, 1 ); ?>>
            <?php esc_html_e( 'Group by Course', 'user-activity-reports' ); ?>
        </label>
        <input type="submit" class="button" value="<?php esc_attr_e( 'Filter', 'user-activity-reports' ); ?>">
    </form>
    <?php

    $items_per_page = 20;
    $current_page = isset( $_GET['paged'] ) ? absint( $_GET['paged'] ) : 1;
    $offset = ( $current_page - 1 ) * $items_per_page;

    $select_sql = "SELECT SQL_CALC_FOUND_ROWS ";
    $from_sql = " FROM {$table_name} t";
    $where_sql = " WHERE 1=1";
    $group_by_sql = " GROUP BY ";
    $order_by_sql = " ORDER BY total_time DESC";
    $limit_sql = " LIMIT %d, %d";

    $params = array();

    if ( $group_by_course ) {
        $select_sql .= " tt.name as course_name, SUM(t.duration_seconds) as total_time, COUNT(DISTINCT t.user_id) as total_users";
        $from_sql .= " INNER JOIN {$wpdb->term_relationships} tr ON t.post_id = tr.object_id";
        $from_sql .= " INNER JOIN {$wpdb->term_taxonomy} tt ON tr.term_taxonomy_id = tt.term_taxonomy_id";
        $group_by_sql .= " tt.name";
    } else {
        $select_sql .= " t.page_url, t.post_id, COUNT(t.id) as total_visits, SUM(t.duration_seconds) as total_time, AVG(t.duration_seconds) as avg_time";
        $group_by_sql .= " t.page_url, t.post_id";
    }

    if ( ! empty( $selected_role ) ) {
        $from_sql .= " INNER JOIN {$wpdb->users} u ON t.user_id = u.ID";
        $from_sql .= " INNER JOIN {$wpdb->usermeta} um ON u.ID = um.user_id";
        $where_sql .= " AND um.meta_key = '{$wpdb->prefix}capabilities' AND um.meta_value LIKE %s";
        $params[] = '%' . $wpdb->esc_like( $selected_role ) . '%';
    }

    if ( ! empty( $start_date ) ) {
        $where_sql .= " AND t.visit_date >= %s";
        $params[] = $start_date;
    }

    if ( ! empty( $end_date ) ) {
        $where_sql .= " AND t.visit_date <= %s";
        $params[] = $end_date;
    }

    $params[] = $offset;
    $params[] = $items_per_page;

    $sql = $select_sql . $from_sql . $where_sql . $group_by_sql . $order_by_sql . $limit_sql;

    $query = $wpdb->prepare( $sql, $params );
    $results = $wpdb->get_results( $query );

    $total_items = $wpdb->get_var( "SELECT FOUND_ROWS()" );

    if ( $results ) {
        ?>
        <a href="<?php echo esc_url( add_query_arg( array( 'action' => 'uar_export_csv', 'report' => 'per_page', 'start_date' => $start_date, 'end_date' => $end_date, 'role' => $selected_role, 'group_by_course' => $group_by_course ), admin_url( 'admin.php' ) ) ); ?>" class="button button-primary"><?php esc_html_e( 'Export to CSV', 'user-activity-reports' ); ?></a>
        <table class="widefat fixed" cellspacing="0">
            <thead>
                <tr>
                    <?php if ( $group_by_course ) : ?>
                        <th><?php esc_html_e( 'Course', 'user-activity-reports' ); ?></th>
                        <th><?php esc_html_e( 'Total Time Spent', 'user-activity-reports' ); ?></th>
                        <th><?php esc_html_e( 'Total Users', 'user-activity-reports' ); ?></th>
                    <?php else : ?>
                        <th><?php esc_html_e( 'Page/Post Title', 'user-activity-reports' ); ?></th>
                        <th><?php esc_html_e( 'URL', 'user-activity-reports' ); ?></th>
                        <th><?php esc_html_e( 'Total Visits', 'user-activity-reports' ); ?></th>
                        <th><?php esc_html_e( 'Total Time Spent', 'user-activity-reports' ); ?></th>
                        <th><?php esc_html_e( 'Average Time per Visit', 'user-activity-reports' ); ?></th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php foreach ( $results as $row ) : ?>
                    <tr>
                        <?php if ( $group_by_course ) : ?>
                            <td><?php echo esc_html( $row->course_name ); ?></td>
                            <td><?php echo esc_html( uar_format_time( $row->total_time ) ); ?></td>
                            <td><?php echo esc_html( $row->total_users ); ?></td>
                        <?php else : ?>
                            <td><?php echo esc_html( get_the_title( $row->post_id ) ); ?></td>
                            <td><a href="<?php echo esc_url( $row->page_url ); ?>" target="_blank"><?php echo esc_url( $row->page_url ); ?></a></td>
                            <td><?php echo esc_html( $row->total_visits ); ?></td>
                            <td><?php echo esc_html( uar_format_time( $row->total_time ) ); ?></td>
                            <td><?php echo esc_html( uar_format_time( round( $row->avg_time ) ) ); ?></td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php
        $total_pages = ceil( $total_items / $items_per_page );
        if ( $total_pages > 1 ) {
            $pagination_args = array(
                'base' => add_query_arg( 'paged', '%#%' ),
                'format' => '',
                'current' => $current_page,
                'total' => $total_pages,
            );
            echo '<div class="tablenav"><div class="tablenav-pages">' . paginate_links( $pagination_args ) . '</div></div>';
        }
    } else {
        echo '<p>' . esc_html__( 'No activity found.', 'user-activity-reports' ) . '</p>';
    }
}

/**
 * Render the Overall Stats report.
 */
function uar_render_overall_stats_report() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'user_page_time_logs';

    $total_active_users = $wpdb->get_var( "SELECT COUNT(DISTINCT user_id) FROM {$table_name}" );
    $average_session_time = $wpdb->get_var( "SELECT AVG(duration_seconds) FROM {$table_name}" );

    ?>
    <h2><?php esc_html_e( 'Overall Stats', 'user-activity-reports' ); ?></h2>
    <table class="form-table">
        <tbody>
            <tr>
                <th scope="row"><?php esc_html_e( 'Total Active Users', 'user-activity-reports' ); ?></th>
                <td><?php echo esc_html( $total_active_users ); ?></td>
            </tr>
            <tr>
                <th scope="row"><?php esc_html_e( 'Average Time per Page Visit', 'user-activity-reports' ); ?></th>
                <td><?php echo esc_html( uar_format_time( round( $average_session_time ) ) ); ?></td>
            </tr>
        </tbody>
    </table>

    <h3><?php esc_html_e( 'Top 10 Most Viewed Pages/Courses', 'user-activity-reports' ); ?></h3>
    <?php
    $top_pages = $wpdb->get_results( "SELECT post_id, SUM(duration_seconds) as total_time, COUNT(*) as total_visits FROM {$table_name} GROUP BY post_id ORDER BY total_time DESC LIMIT 10" );
    if ( $top_pages ) {
        ?>
        <table class="widefat fixed" cellspacing="0">
            <thead>
                <tr>
                    <th><?php esc_html_e( 'Page/Post Title', 'user-activity-reports' ); ?></th>
                    <th><?php esc_html_e( 'Total Time Spent', 'user-activity-reports' ); ?></th>
                    <th><?php esc_html_e( 'Total Visits', 'user-activity-reports' ); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ( $top_pages as $page ) : ?>
                    <tr>
                        <td><?php echo esc_html( get_the_title( $page->post_id ) ); ?></td>
                        <td><?php echo esc_html( uar_format_time( $page->total_time ) ); ?></td>
                        <td><?php echo esc_html( $page->total_visits ); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php
    } else {
        echo '<p>' . esc_html__( 'No data available.', 'user-activity-reports' ) . '</p>';
    }
    ?>

    <h3><?php esc_html_e( 'Inactive Users', 'user-activity-reports' ); ?></h3>
    <?php $inactive_days = isset( $_GET['inactive_days'] ) ? intval( $_GET['inactive_days'] ) : 30; ?>
    <form method="get">
        <input type="hidden" name="page" value="uar-user-activity-reports">
        <input type="hidden" name="tab" value="overall_stats">
        <label for="inactive_days"><?php esc_html_e( 'Show users inactive for at least', 'user-activity-reports' ); ?></label>
        <select id="inactive_days" name="inactive_days">
            <option value="30" <?php selected( $inactive_days, 30 ); ?>>30</option>
            <option value="60" <?php selected( $inactive_days, 60 ); ?>>60</option>
            <option value="90" <?php selected( $inactive_days, 90 ); ?>>90</option>
        </select>
        <label for="inactive_days"><?php esc_html_e( 'days', 'user-activity-reports' ); ?></label>
        <input type="submit" class="button" value="<?php esc_attr_e( 'Filter', 'user-activity-reports' ); ?>">
    </form>
    <?php
    $inactive_date = date( 'Y-m-d', strtotime( "-{$inactive_days} days" ) );
    
    $inactive_users = $wpdb->get_results( $wpdb->prepare(
        "SELECT u.ID, u.display_name
         FROM {$wpdb->users} u
         LEFT JOIN (
             SELECT DISTINCT user_id
             FROM {$table_name}
             WHERE visit_date >= %s
         ) AS active_users ON u.ID = active_users.user_id
         WHERE active_users.user_id IS NULL",
        $inactive_date
    ) );
    
    if ( ! empty( $inactive_users ) ) {
        ?>
        <table class="widefat fixed" cellspacing="0">
            <thead>
                <tr>
                    <th><?php esc_html_e( 'User', 'user-activity-reports' ); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ( $inactive_users as $user ) : ?>
                    <tr>
                        <td><?php echo esc_html( $user->display_name ); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php
    } else {
        echo '<p>' . esc_html__( 'No inactive users found.', 'user-activity-reports' ) . '</p>';
    }
}
