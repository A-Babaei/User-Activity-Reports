<?php
/**
 * CSV Export
 *
 * @package User_Activity_Reports
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
    die;
}

/**
 * Format seconds into a human-readable format for CSV.
 */
function uar_format_time_csv( $seconds ) {
    $hours = floor( $seconds / 3600 );
    $minutes = floor( ( $seconds / 60 ) % 60 );
    $seconds = $seconds % 60;
    return sprintf( '%02d:%02d:%02d', $hours, $minutes, $seconds );
}

/**
 * Handle the CSV export request.
 */
function uar_handle_csv_export() {
    if ( ! isset( $_GET['action'] ) || $_GET['action'] !== 'uar_export_csv' || ! isset( $_GET['report'] ) ) {
        return;
    }

    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }

    $report = sanitize_key( $_GET['report'] );
    $filename = "uar-{$report}-" . date( 'Y-m-d' ) . '.csv';

    header( 'Content-Type: text/csv; charset=utf-8' );
    header( 'Content-Disposition: attachment; filename=' . $filename );

    $output = fopen( 'php://output', 'w' );

    global $wpdb;
    $table_name = $wpdb->prefix . 'user_page_time_logs';

    $start_date = isset( $_GET['start_date'] ) ? sanitize_text_field( $_GET['start_date'] ) : '';
    $end_date = isset( $_GET['end_date'] ) ? sanitize_text_field( $_GET['end_date'] ) : '';

    if ( $report === 'per_user' && isset( $_GET['user_id'] ) ) {
        $user_id = intval( $_GET['user_id'] );
        fputcsv( $output, array( 'Page/Post Title', 'URL', 'Total Visits', 'Total Time Spent', 'Average Time per Visit' ) );

        $sql = "SELECT page_url, post_id, COUNT(*) as total_visits, SUM(duration_seconds) as total_time, AVG(duration_seconds) as avg_time FROM {$table_name} WHERE user_id = %d";
        $params = array( $user_id );

        if ( ! empty( $start_date ) ) {
            $sql .= " AND visit_date >= %s";
            $params[] = $start_date;
        }

        if ( ! empty( $end_date ) ) {
            $sql .= " AND visit_date <= %s";
            $params[] = $end_date;
        }

        $sql .= " GROUP BY page_url, post_id";
        
        $query = $wpdb->prepare( $sql, $params );
        $results = $wpdb->get_results( $query );

        if ( $results ) {
            foreach ( $results as $row ) {
                fputcsv( $output, array( get_the_title( $row->post_id ), $row->page_url, $row->total_visits, uar_format_time_csv( $row->total_time ), uar_format_time_csv( round( $row->avg_time ) ) ) );
            }
        }
    } elseif ( $report === 'per_page' ) {
        $selected_role = isset( $_GET['role'] ) ? sanitize_text_field( $_GET['role'] ) : '';
        $group_by_course = isset( $_GET['group_by_course'] ) ? 1 : 0;

        if ( $group_by_course ) {
            fputcsv( $output, array( 'Course', 'Total Time Spent', 'Total Users' ) );
            $sql = "SELECT tt.name as course_name, SUM(t.duration_seconds) as total_time, COUNT(DISTINCT t.user_id) as total_users FROM {$table_name} t";
            $sql .= " INNER JOIN {$wpdb->term_relationships} tr ON t.post_id = tr.object_id";
            $sql .= " INNER JOIN {$wpdb->term_taxonomy} tt ON tr.term_taxonomy_id = tt.term_taxonomy_id";
        } else {
            fputcsv( $output, array( 'Page/Post Title', 'URL', 'Total Visits', 'Total Time Spent', 'Average Time per Visit' ) );
            $sql = "SELECT t.page_url, t.post_id, COUNT(t.id) as total_visits, SUM(t.duration_seconds) as total_time, AVG(t.duration_seconds) as avg_time FROM {$table_name} t";
        }
        
        $params = array();

        if ( ! empty( $selected_role ) ) {
            $sql .= " INNER JOIN {$wpdb->users} u ON t.user_id = u.ID";
            $sql .= " INNER JOIN {$wpdb->usermeta} um ON u.ID = um.user_id";
            $sql .= " WHERE um.meta_key = '{$wpdb->prefix}capabilities' AND um.meta_value LIKE %s";
            $params[] = '%' . $wpdb->esc_like( $selected_role ) . '%';
        } else {
            $sql .= " WHERE 1=1";
        }

        if ( ! empty( $start_date ) ) {
            $sql .= " AND visit_date >= %s";
            $params[] = $start_date;
        }

        if ( ! empty( $end_date ) ) {
            $sql .= " AND visit_date <= %s";
            $params[] = $end_date;
        }
        
        if ( $group_by_course ) {
            $sql .= " GROUP BY tt.name ORDER BY total_time DESC";
        } else {
            $sql .= " GROUP BY t.page_url, t.post_id ORDER BY total_time DESC";
        }

        $query = $wpdb->prepare( $sql, $params );
        $results = $wpdb->get_results( $query );

        if ( $results ) {
            foreach ( $results as $row ) {
                if ( $group_by_course ) {
                    fputcsv( $output, array( $row->course_name, uar_format_time_csv( $row->total_time ), $row->total_users ) );
                } else {
                    fputcsv( $output, array( get_the_title( $row->post_id ), $row->page_url, $row->total_visits, uar_format_time_csv( $row->total_time ), uar_format_time_csv( round( $row->avg_time ) ) ) );
                }
            }
        }
    }

    fclose( $output );
    exit;
}
add_action( 'admin_init', 'uar_handle_csv_export' );
