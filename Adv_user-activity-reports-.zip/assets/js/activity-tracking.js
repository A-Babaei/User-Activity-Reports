document.addEventListener('DOMContentLoaded', function() {
    if (typeof uar_activity_tracking === 'undefined' || !uar_activity_tracking.is_user_logged_in) {
        return;
    }

    let startTime = new Date();
    let logId = null;
    let heartbeatInterval = null;
    let accumulatedDuration = 0; // To store time from previous visible periods

    function sendRequest(action, data, async = true, callback = null) {
        const formData = new FormData();
        formData.append('action', 'uar_activity_' + action);
        formData.append('nonce', uar_activity_tracking.nonce);
        for (const key in data) {
            formData.append(key, data[key]);
        }

        const url = uar_activity_tracking.ajax_url;

        if (navigator.sendBeacon && !async) {
            // Beacon API does not support callbacks
            navigator.sendBeacon(url, formData);
        } else {
            const xhr = new XMLHttpRequest();
            xhr.open('POST', url, async);
            xhr.send(formData);
            xhr.onload = function() {
                if (xhr.status === 200) {
                    const response = JSON.parse(xhr.responseText);
                    if (callback) {
                        callback(response);
                    }
                }
            };
        }
    }

    function startTracking() {
        startTime = new Date();
        accumulatedDuration = 0;
        sendRequest('start', {
            post_id: uar_activity_tracking.post_id,
            page_url: window.location.href,
            start_time: startTime.toISOString().slice(0, 19).replace('T', ' ')
        }, true, function(response) {
            if (response.success && response.data.log_id) {
                logId = response.data.log_id;
                startHeartbeat();
            }
        });
    }

    function stopTracking(event) {
        stopHeartbeat();
        if (document.visibilityState === 'visible') {
            updateDuration(false);
        } else {
            // If the tab is hidden, just send the accumulated duration.
            sendRequest('update', {
                log_id: logId,
                duration_seconds: accumulatedDuration
            }, false);
        }
    }
    
    function startHeartbeat() {
        if (heartbeatInterval) {
            clearInterval(heartbeatInterval);
        }
        heartbeatInterval = setInterval(heartbeat, 30000); // 30-second heartbeat
    }

    function stopHeartbeat() {
        if (heartbeatInterval) {
            clearInterval(heartbeatInterval);
            heartbeatInterval = null;
        }
    }

    function heartbeat() {
        if (document.visibilityState === 'visible') {
            updateDuration(true);
        }
    }

    function updateDuration(async) {
        if (!logId) return;

        const now = new Date();
        const currentDuration = Math.round((now - startTime) / 1000);
        const totalDuration = accumulatedDuration + currentDuration;

        sendRequest('update', {
            log_id: logId,
            duration_seconds: totalDuration
        }, async);
    }

    function handleVisibilityChange() {
        if (document.visibilityState === 'hidden') {
            stopHeartbeat();
            const now = new Date();
            const currentDuration = Math.round((now - startTime) / 1000);
            accumulatedDuration += currentDuration;
        } else {
            startTime = new Date();
            startHeartbeat();
        }
    }
    
    startTracking();

    window.addEventListener('beforeunload', stopTracking);
    document.addEventListener('visibilitychange', handleVisibilityChange);
});
