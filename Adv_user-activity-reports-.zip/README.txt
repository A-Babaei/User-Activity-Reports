=== Protected Content ===
Contributors: Jules
Tags: protected content, user activity, tracking
Requires at least: 5.0
Tested up to: 6.5
Stable tag: 1.2.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Protects premium content for enrolled/membership users and tracks user activity.

== Description ==

This plugin provides two main features:
1.  **Protected Content:** Restrict access to premium content to logged-in users with specific membership levels or course enrollments. (This is a placeholder, the focus of this development was the User Activity Reports feature).
2.  **User Activity Reports:** Track how logged-in users spend time on your site, including which pages they visit and for how long.

== Installation ==

1.  Upload the `protected-content` folder to the `/wp-content/plugins/` directory.
2.  Activate the plugin through the 'Plugins' menu in WordPress.

== Usage ==

**User Activity Reports**

1.  Navigate to "Protected Content > User Activity Reports" in the WordPress admin menu.
2.  The reports are divided into three tabs:
    *   **Per User Report:** Select a user and a date range to see their activity.
    *   **Per Page/Course Report:** See which pages are most popular, with filters for date range, user role, and category. You can also group the report by course.
    *   **Overall Stats:** View high-level statistics, including a list of the most viewed pages and a list of inactive users.
3.  You can export the "Per User" and "Per Page/Course" reports to CSV.

**Settings**

1.  Navigate to "Protected Content > Settings".
2.  Here you can:
    *   Enable or disable user activity tracking.
    *   Exclude certain user roles from tracking.
    *   Exclude specific post IDs from tracking.
    *   Configure the data retention period for the activity logs.

== Changelog ==

= 1.2.0 =
* Fixed: Per Page/Course report SQL and Group by Course display/export
* Fixed: Inactive Users query performance on large sites
* Fixed: CSV export now matches on-screen view and filters
* Removed PHP notices in reports
* Added human-readable time formatting
* Minor UI/UX improvements and admin notices

= 1.0.0 =
* Added User Activity Reports feature to track time spent on pages per user.
* Added admin dashboard with "Per User," "Per Page/Course," and "Overall Stats" reports.
* Added settings to enable/disable tracking, exclude user roles and post IDs, and configure data retention.
* Added CSV export functionality to reports.
* Added data pruning via WP-Cron to automatically delete old logs.
